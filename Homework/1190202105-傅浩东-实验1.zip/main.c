#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define MAX 200
struct celltype
{
    int nume;//����
    int deno;//��ĸ
    int power;//�η�
    struct celltype *next;
};
typedef struct celltype *LIST;
typedef struct celltype *position;
//��������������ͷ�ڵ�
LIST MakeNull()
{
    LIST s;
    s = (struct celltype *)malloc(sizeof(struct celltype));
    s->next = NULL;
    return s;
}
//ɾ��p����һ���ڵ�
void Delete(position p)
{
    position q;
    if(p->next != NULL)
    {
        q = p->next;
        p->next = q->next;
        free(q);
    }
}
//�����������ͷ�ڵ�
void ClearLink(LIST L)
{
    position p;
    while(L->next)
    {
        p = L->next;
        L->next = p->next;
        free(p);
    }

}
//��ʾ����
void ShowData(LIST L)
{
    position p = L;
    if(p->next == NULL)
    {
        printf("0\n");
    }
    else
    {
        while(p->next)
        {
            if(p->next->deno == 1)
            {
                if(p->next->nume > 0)
                    printf("+%d", p->next->nume);
                else
                    printf("%d", p->next->nume);
            }
            else
            {
                if(p->next->nume > 0)
                    printf("+%d/%d",p->next->nume,p->next->deno);
                else
                    printf("%d/%d",p->next->nume,p->next->deno);
            }
            if(p->next->power == 0);
            else if(p->next->power == 1)
                printf("*x");
            else
                printf("*x^%d",p->next->power);
            p = p->next;
        }
    }
    printf("\n");
}
//p����һ���ڵ���룬���ظýڵ��ָ��
position Insert(int nume, int deno, int power, position p)
{
    LIST q;
    q = (struct celltype *)malloc(sizeof(struct celltype));
    q->nume = nume; q->deno = deno; q->power = power;
    q->next = p->next;
    p->next = q;
    return q;
}
//�����Լ��
int MaxComDiv(int num1, int num2)
{
    int temp;
    while(num2)
    {
        temp = num1%num2;
        num1 = num2;
        num2 = temp;
    }
    return num1;
}
/*
�ַ���ת��Ϊ�������棺
ÿһ����С�+�����ߡ�-�������˵�һ��������Ա�ʡ�ԣ��������
ÿ������+�����ߡ�-������������һ���µĽڵ�
���ա�/��֮��Ϊ��ĸ����x^��֮��Ϊ������ԭ��ת��Ϊ�����ṹ
*/
void Change(char str[], LIST A)
{
    int i, temp;
    position p = A;
    if(str[0] == '-')
        i=0;
    else
    {
        str[-1]='+';
        i=-1;
    }
    while(str[i] != '#') //��#��Ϊ������־
    {
        temp = 0; //���������ı�־�����㴦������
        if(str[i]=='+' || str[i]=='-')   //��+��-��
        {
            if(str[i]=='-') temp = 1;
            p = Insert(1, 1, 0, p);
            i++;
            if(str[i]=='x')
            {
                i++;
                if(str[i]!='^') p->power = 1;
            }
            else
            {
                p->nume = 0;
                while(str[i]>='0' && str[i]<='9')
                {
                    p->nume = 10*p->nume+(int)(str[i]-'0');
                    i++;
                }
            }
            if(temp == 1) p->nume = - p->nume;
        }
        else if(str[i]=='/')  //��/��
        {
            p->deno = 0;
            i++;
            while(str[i]>='0'&&str[i]<='9')
            {
                p->deno = 10*p->deno+(int)(str[i]-'0');
                i++;
            }
        }
        else if(str[i]=='*') i++;
        else if(str[i]=='x')
        {
            i++;
            if(str[i]!='^') p->power = 1;
        }
        else if(str[i]=='^')
        {
            i++;
            while(str[i]>='0'&&str[i]<='9')
            {
                p->power = 10*p->power+(int)(str[i]-'0');
                i++;
            }
        }
        else if(str[i]=='#');
        else
        {
            printf(" %c\n Wrong!\n",str[i]);
            exit(0);
        }
    }
}
//ѡ�����򣬽���
void Sort(LIST A)
{
    position p = A, q = A, temp;
    int t, tnume, tdeno, tpower;
    while(p->next)
    {
        temp = p;
        while(q->next)
        {
            if(q->next->power >= temp->next->power)
                temp = q;
            q = q->next;
        }
        if(temp == p)
        {
            p = p->next;
        }
        else if(p->power == temp->next->power)
        {
            p->nume = p->nume*temp->next->deno
                    + p->deno*temp->next->nume;
            p->deno = p->deno*temp->next->deno;
            t = MaxComDiv(abs(p->nume), p->deno);
            p->nume /= t; p->deno /= t;
            Delete(temp);
        }
        else
        {
            p = p->next; temp = temp->next;
            tnume = p->nume; p->nume = temp->nume; temp->nume = tnume;
            tdeno = p->deno; p->deno = temp->deno; temp->deno = tdeno;
            tpower = p->power; p->power = temp->power; temp->power = tpower;
        }
        q = p;
    }
}
//�ӷ������Ѿ��ź����������
void Addition(LIST A, LIST B, LIST Sum)
{
    position a = A, b = B, s = Sum;
    int tnume, tdeno, t;
    if(Sum->next==NULL)
    {
        while(a->next && b->next)
        {
            if(a->next->power > b->next->power)
            {
                a = a->next;
                Insert(a->nume, a->deno, a->power, s);
                s = s->next;
            }
            else if(b->next->power > a->next->power)
            {
                b = b->next;
                Insert(b->nume, b->deno, b->power, s);
                s = s->next;
            }
            else
            {
                a = a->next; b = b->next;
                tnume = a->nume*b->deno + b->nume*a->deno;
                if(tnume == 0) continue;
                else
                {
                    tdeno = a->deno*b->deno;
                    t = MaxComDiv(abs(tnume), tdeno);
                    tnume = tnume/t; tdeno = tdeno/t;
                    Insert(tnume, tdeno, a->power, s);
                    s = s->next;
                }
            }
        }
        while(a->next)
        {
            a = a->next;
            Insert(a->nume, a->deno, a->power, s);
            s = s->next;
        }
        while(b->next)
        {
            b = b->next;
            Insert(b->nume, b->deno, b->power, s);
            s = s->next;
        }
    }
}
//����A-B�����üӷ��Ƚ�B��ϵ��ȡ�������֮����ȡ��
void Subtraction(LIST A, LIST B, LIST Sub)
{
    position p = B;
    while(p->next)
    {
        p->next->nume = -p->next->nume;
        p = p->next;
    }
    Addition(A, B, Sub);
    p = B;
    while(p->next)
    {
        p->next->nume = -p->next->nume;
        p = p->next;
    }
}
//��һ�ε�����ָ����ϵ����ָ����һ��ָ��Ϊ0��ɾ������
void Derivative(LIST A)
{
    position p = A;
    int t;
    while(p->next)
    {
        if(p->next->power == 0)
            Delete(p);
        else
        {
            p->next->nume = p->next->nume*p->next->power;
            t = MaxComDiv(abs(p->next->nume), p->next->deno);
            p->next->nume = p->next->nume/t;
            p->next->deno = p->next->deno/t;
            p->next->power--;
        }
        p = p->next;
        if(p == NULL) break;
    }
}
//����x=x0�Ľ��
float Calculate(LIST A, float x)
{
    float sum = 0;
    position p = A->next;
    do
    {
        sum += (float)(p->nume)/(p->deno)*pow(x, p->power);
        p = p->next;
    }while(p);
    return sum;
}
//�˷�����A��ÿһ��ȥ��B��ÿһ��
void Multiplication(LIST A, LIST B, LIST Mul)
{
    position p = A, q = B, temp, ts;
    int tnume, tdeno, tpower, t;
    while(p->next)
    {
        q = B;
        while(q->next)
        {
            tnume = p->next->nume * q->next->nume;
            tdeno = p->next->deno * q->next->deno;
            t = MaxComDiv(abs(tnume), tdeno);
            tnume = tnume/t; tdeno = tdeno/t;
            tpower = p->next->power + q->next->power;
            if(Mul->next == NULL)
                Insert(tnume, tdeno, tpower, Mul);
            else
            {
                temp = Mul;
                while(temp->next)
                {
                    if(temp->next->power == tpower)
                    {
                        temp->next->nume = tnume * temp->next->deno
                                         + tdeno * temp->next->nume;
                        if(temp->next->nume == 0)
                        {
                            ts = temp->next;
                            temp->next = ts->next;
                            free(ts);
                            break;
                        }
                        temp->next->deno = tdeno * temp->next->deno;
                        t = MaxComDiv(abs(temp->next->nume), temp->next->deno);
                        temp->next->nume /= t; temp->next->deno /= t;
                        break;
                    }
                    else if(temp->next->power < tpower)
                    {
                        Insert(tnume, tdeno, tpower, temp);
                        break;
                    }
                    else
                    {
                        temp = temp->next;
                        if(temp->next == NULL)
                        {
                            Insert(tnume, tdeno, tpower, temp);
                            break;
                        }
                    }
                }
            }
            q = q->next;
        }
        p = p->next;
    }
}
//������AΪ��������ʽ��BΪ������ʽ
void Division(LIST A, LIST B, LIST Ans, LIST Divisor, LIST Rem)
{
    Divisor->next = B->next;//����ʽ
    LIST tempAns = MakeNull();//�ݴ���
    tempAns->next = MakeNull();
    LIST tempMul = MakeNull(), tempRem = MakeNull();
    position p = A, r = Rem, a = Ans;
    int t;
    //��rem�汻������ʽ
    while(p->next)
    {
        r = Insert(p->next->nume, p->next->deno, p->next->power, r);
        p = p->next;
    }
    while(Rem->next->power >= Divisor->next->power)
    {
        //��ߴ�������Ľ��
        tempAns->next->power = Rem->next->power - Divisor->next->power;
        tempAns->next->nume = Rem->next->nume * Divisor->next->deno;
        tempAns->next->deno = Rem->next->deno * Divisor->next->nume;
        t = MaxComDiv(abs(tempAns->next->nume), abs(tempAns->next->deno));
        if(tempAns->next->nume * tempAns->next->deno > 0)
        {
            tempAns->next->nume = abs(tempAns->next->nume)/t;
            tempAns->next->deno = abs(tempAns->next->deno)/t;
        }
        else
        {
            tempAns->next->nume = -abs(tempAns->next->nume)/t;
            tempAns->next->deno = abs(tempAns->next->deno)/t;
        }
        Multiplication(tempAns, Divisor, tempMul);
        Subtraction(Rem, tempMul, tempRem);
        ClearLink(Rem);
        Rem->next = tempRem->next;
        tempRem->next = NULL;
        ClearLink(tempMul);
        a = Insert(tempAns->next->nume,
                   tempAns->next->deno, tempAns->next->power, a);
        if(Rem->next == NULL) break;
    }
}

int main()
{
    int k = 2, i = 0;
    float x = 1.5;
    char Ac[MAX], Bc[MAX];
    //���ļ�in���룬out���
    freopen("in.txt","r",stdin);
    freopen("out.txt","w",stdout);
    fgets(Ac, MAX, stdin);
    fgets(Bc, MAX, stdin);
    scanf("%f", &x);
    scanf("%d", &k);
    LIST A = MakeNull(), B = MakeNull();
    LIST Sum = MakeNull(), Sub = MakeNull(), Mul = MakeNull();
    LIST Ans = MakeNull(), Divisor = MakeNull(), Rem = MakeNull();
    Change(Ac, A); Change(Bc, B);
    Sort(A); Sort(B);
    printf(" A:"); ShowData(A);
    printf(" B:"); ShowData(B);
    Addition(A, B, Sum);//�ӷ�
    Subtraction(A, B, Sub);//����
    Multiplication(A, B, Mul);//�˷�
    Division(A, B, Ans, Divisor, Rem);//����
    printf("A+B: "); ShowData(Sum);
    printf("A-B: "); ShowData(Sub);
    printf("A*B: "); ShowData(Mul);
    printf("A/B:\n ");
    printf("�̶���ʽ��"); ShowData(Ans);
    printf("��������ʽ:"); ShowData(Rem);
    printf("A(%f)=%f\n", x, Calculate(A, x));//��A��ֵ
    printf("B(%f)=%f\n", x, Calculate(B, x));//��A��ֵ
    for(i = 0; i<k ;i++)
    {
        Derivative(A); Derivative(B);
    }
    printf("A^(%d)=", k); ShowData(A);
    printf("B^(%d)=", k); ShowData(B);
    fclose(stdin);
    fclose(stdout);
    return 0;
}
