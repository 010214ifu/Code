#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define MAX_CHILD 16
#define MAX_CHAR 200
#define MAX_LENGTH_HCODE 20

typedef struct
{
    char ch;
    int count;
}CharNode;

typedef struct
{
    CharNode C;
    int parent;
    int child[MAX_CHILD];
}HTNode;

typedef struct
{
    char ch;
    char bits[MAX_LENGTH_HCODE];
}HFCode;

HTNode HaffmanCode[2*MAX_CHAR-1];
HFCode H[MAX_CHAR];

int decimal;//������
int number=0;//�ַ���

//��ʼ�����飬�����ӽڵ�͸��ڵ㶼��Ϊ-1
void Initi();
//��Input.txt�ļ����������ζ�ȡ�ַ�������ÿ���ַ������������ַ�����
int ReadData();
//�Ѳ��룬����n��ʾ������Ǳ�n������
void Insert(int n, int count, char ch, int child[]);
//������С��
void CreateHeap();
//ѡ����СԪ�أ�maxpos��ʾ�ѵ����Ǳ꣬��ѡ���������СԪ�ز����ڽǱ�Ϊnext��λ��
int ChooseMinHeap(int maxpos, int next);
//�������������㷨
void CreateHT();
//���չ����������б��룬child�Ǳ��С�������ζ�Ӧ0��1��������9��a��������f
void SetHaffmanCoding();
//���ݺ��ӽڵ��λ�÷��ر���
char ChildPositionChar(int p, int c);
//�����½��б���
void WriteHaffmanEssay();
//�Ա����ļ����н���
void DecodingHaffman();
//���㲢����ѹ����
double CompressionRatio(int SumChar);

int main()
{
    int SumChar,i,j;
    printf("Input decimal (2-16): ");
    scanf("%d", &decimal);
    while(decimal<2||decimal>16)
    {
        printf("Wrong! Input again:");
        scanf("%d", &decimal);
    }
    Initi();
    SumChar=ReadData();
    printf("\ncharacter  frequency\n");
    for(j=1; j<=number; j++)
    {
        if(HaffmanCode[j].C.ch!='\n')
            printf("  %c       %f\n", HaffmanCode[j].C.ch,
                   (float)HaffmanCode[j].C.count/SumChar);
        else if(HaffmanCode[j].C.ch=='\n')
            printf(" \\n       %f\n",(float)HaffmanCode[j].C.count/SumChar);
    }
    CreateHeap();
    CreateHT();
    SetHaffmanCoding();
    printf("\nEncode Characters\n");
    for(i=1; i<=number; i++)
    {
        if(H[i].ch!='\n')
            printf("  %c   %s\n", H[i].ch, H[i].bits);
        else
            printf(" \\n   %s\n", H[i].bits);
    }
    WriteHaffmanEssay();
    DecodingHaffman();
    printf("\nCompression ratio: %f %%\n", CompressionRatio(SumChar)*100);
    return 0;
}

void Initi()
{
    for(int i=0; i<2*MAX_CHAR-1; i++)
    {
        HaffmanCode[i].parent=-1;
        for(int j=0; j<decimal; j++)
            HaffmanCode[i].child[j]=-1;
    }
}

int ReadData()
{
    char ch;
    int counter=0, flag;
    FILE *fp=fopen("Input.txt", "r");//�ļ�Input.txtΪ�����ļ�
    if (fp == NULL)
	{
		printf("Wrong!\n");
		exit(0);
	}
	while(1)
    {
        if((ch=fgetc(fp))==EOF) break;//֪��ȡ�����ַ����˳�ѭ��
        counter++; flag=0;
        for(int i=1; i<=number; i++)
        {
            if(ch==HaffmanCode[i].C.ch)
            {
                HaffmanCode[i].C.count++;
                flag=1;//flagΪ1���ҵ���ͬ���ַ�
                break;
            }
        }
        if(flag==0)//flagΪ0��û�ҵ���ͬ�ַ�������һ���ռ�����ch
        {
            number++;
            HaffmanCode[number].C.ch=ch;
            HaffmanCode[number].C.count=1;
        }
    }
    fclose(fp);
    return counter;
}

void Insert(int n, int count, char ch, int child[])
{
    int i=n;
    while(i!=1 && count<HaffmanCode[i/2].C.count)//�ȸ��ڵ�С�򽻻�λ��
    {
        HaffmanCode[i].C.count=HaffmanCode[i/2].C.count;
        HaffmanCode[i].C.ch=HaffmanCode[i/2].C.ch;
        HaffmanCode[i].parent=HaffmanCode[i/2].parent;
        for(int j=0; j<decimal; j++)//�ӽڵ�Ľ������Լ��ӽڵ�ĸ��ڵ�任
        {
            HaffmanCode[i].child[j]=HaffmanCode[i/2].child[j];
            if(HaffmanCode[i].child[j]!=-1)
                HaffmanCode[HaffmanCode[i].child[j]].parent=i;
        }
        i/=2;
    }
    HaffmanCode[i].C.count=count;
    HaffmanCode[i].C.ch=ch;
    for(int j=0; j<decimal; j++)
    {
        HaffmanCode[i].child[j]=child[j];
        if(HaffmanCode[i].child[j]!=-1)
            HaffmanCode[HaffmanCode[i].child[j]].parent=i;
    }
    HaffmanCode[i].parent=-1;
}

void CreateHeap()
{
    for(int i=2; i<=number; i++)//��Ԫ�ذ��Ǳ�����������
        Insert(i, HaffmanCode[i].C.count,
               HaffmanCode[i].C.ch, HaffmanCode[i].child);
}

int ChooseMinHeap(int maxpos, int next)
{
    int parent=1, child=2;
    int tempcount, tempchild[decimal];
    char tempch;
    if(maxpos>=1)
    {
        tempcount=HaffmanCode[1].C.count;
        tempch=HaffmanCode[1].C.ch;
        for(int j=0; j<decimal; j++)
            tempchild[j]=HaffmanCode[1].child[j];
        maxpos--;
        while(child<=maxpos)
        {
            if(child<maxpos&&HaffmanCode[child].C.count>HaffmanCode[child+1].C.count)
                child++;
            if(HaffmanCode[maxpos+1].C.count<=HaffmanCode[child].C.count)
                break;
            HaffmanCode[parent].C.count=HaffmanCode[child].C.count;
            HaffmanCode[parent].C.ch=HaffmanCode[child].C.ch;
            for(int k=0; k<decimal; k++)
            {
                HaffmanCode[parent].child[k]=HaffmanCode[child].child[k];
                if(HaffmanCode[parent].child[k]!=-1)
                    HaffmanCode[HaffmanCode[parent].child[k]].parent=parent;
            }
            parent=child;
            child*=2;
        }
        HaffmanCode[parent].C.count=HaffmanCode[maxpos+1].C.count;
        HaffmanCode[parent].C.ch=HaffmanCode[maxpos+1].C.ch;
        for(int t=0; t<decimal; t++)
        {
            HaffmanCode[parent].child[t]=HaffmanCode[maxpos+1].child[t];
            if(HaffmanCode[parent].child[t]!=-1)
                HaffmanCode[HaffmanCode[parent].child[t]].parent=parent;
        }
    }
    HaffmanCode[next].C.count=tempcount;
    HaffmanCode[next].C.ch=tempch;
    for(int s=0; s<decimal; s++)
    {
        HaffmanCode[next].child[s]=tempchild[s];
        if(HaffmanCode[next].child[s]!=-1)
            HaffmanCode[HaffmanCode[next].child[s]].parent=next;
    }
    return tempcount;
}

void CreateHT()
{
    int x=number%(decimal-1);
    int tempchild[decimal], maxpos=number, next=number+1, sum=0;
    for(int j=0; j<decimal; j++) tempchild[j]=-1;
/*
����ÿ���ַ������ܸպù���һ���ӽڵ㶼Ϊ���Ĺ�������
������������������������ȡx������һ��������һ�������������
*/
    if(x==0) x=decimal-1;
    if(x>1)
    {
        for(int i=0; i<x; i++)
        {
            sum+=ChooseMinHeap(maxpos, next);
            tempchild[i]=next;
            maxpos--; next++;
        }
        Insert(maxpos+1, sum, '@',tempchild); maxpos++;
    }
    while(maxpos!=1)
    {
        sum=0;
        for(int k=0; k<decimal; k++)
        {
            sum+=ChooseMinHeap(maxpos, next);
            tempchild[k]=next;
            maxpos--; next++;
        }
        Insert(maxpos+1, sum, '@',tempchild); maxpos++;
    }
}

void SetHaffmanCoding()
{
    int leaf=0, start, c, p;
    char cd[number+1];
    cd[number]='\0';
    for(int i=number+1; leaf<number; i++)
    {
        if(HaffmanCode[i].child[0]==-1)
        {
            start=number; c=i;
            H[++leaf].ch=HaffmanCode[i].C.ch;
            while((p=HaffmanCode[c].parent)>=0)
            {
                cd[--start]=ChildPositionChar(p, c);
                c=p;
            }
            strcpy(H[leaf].bits, &cd[start]);
        }
    }
}

char ChildPositionChar(int p, int c)
{
    int i=0;
    while(i<decimal)
    {
        if(HaffmanCode[p].child[i]==c) break;
        i++;
    }

    if(i==0) return '0';
    else if(i==1) return '1';
    else if(i==2) return '2';
    else if(i==3) return '3';
    else if(i==4) return '4';
    else if(i==5) return '5';
    else if(i==6) return '6';
    else if(i==7) return '7';
    else if(i==8) return '8';
    else if(i==9) return '9';
    else if(i==10) return 'a';
    else if(i==11) return 'b';
    else if(i==12) return 'c';
    else if(i==13) return 'd';
    else if(i==14) return 'e';
    else return 'f';
}

void WriteHaffmanEssay()
{
    char ch;
    int i;
    FILE *fp_read, *fp_write;
    fp_read=fopen("Input.txt", "r");
    fp_write=fopen("HaffmanCodingEssay.txt", "w");
    if (fp_read == NULL)
	{
		printf("Wrong(Input.txt)!\n");
		exit(0);
	}
	if (fp_write == NULL)
	{
		printf("Wrong(HaffmanCodingEssay.txt)!\n");
		exit(0);
	}
	while(1)
    {
        if((ch=fgetc(fp_read))==EOF) break;
        for(i=1; i<=number; i++)
            if(ch==H[i].ch) break;
        fputs(H[i].bits, fp_write);
    }
    fclose(fp_read);
    fclose(fp_write);
}

void DecodingHaffman()
{
    char temp[MAX_LENGTH_HCODE]={'\0'};
    int i=0, j, k;
    FILE *fp_read;
    FILE *fp_write;
    fp_read=fopen("HaffmanCodingEssay.txt", "r");
    fp_write=fopen("DecodingEssay.txt", "w");
    if(fp_read==NULL||fp_write==NULL)
    {
        printf("Wrong!\n");
        exit(0);
    }
    while(1)
    {
        if((temp[i++]=fgetc(fp_read))==EOF) break;
        for(j=1; j<=number; j++)
        {
            if(strcmp(temp, H[j].bits)==0)
            {
                fputc(H[j].ch, fp_write);
                i=0;
                for(k=0; k<MAX_LENGTH_HCODE; k++)
                    temp[k]='\0';
            }
        }
    }
    fclose(fp_read);
}

double CompressionRatio(int SumChar)
{
    int temp=0, CompressionBits=0, CharBits;
    char ch;
    FILE *fp_read;
    fp_read=fopen("HaffmanCodingEssay.txt", "r");
    if(fp_read==NULL)
    {
        printf("Wrong!\n");
        exit(0);
    }
    while(1)
    {
        if((ch=fgetc(fp_read))==EOF) break;
        temp++;
    }
    CompressionBits=temp*(int)ceil(log(decimal)/log(2));
    CharBits=SumChar*8;
    return (double)CompressionBits/CharBits;
}