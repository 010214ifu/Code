#include <stdio.h>
#include <stdlib.h>
#define MAXBUFFER 100

struct celltype
{
    char data;
    struct celltype *next;
};
typedef struct celltype *STACK;

struct node
{
    float data;
    struct node *next;
};
typedef struct node *AnsSTACK;

//������ջ
STACK MakeCharNull()
{
    STACK s;
    s = (struct celltype *)malloc(sizeof(struct celltype));
    s->next = NULL;
    return s;
}
AnsSTACK MakeAnsNull()
{
    AnsSTACK s;
    s = (struct node *)malloc(sizeof(struct node));
    s->next = NULL;
    return s;
}

//��ջ
void Push(char elm, STACK stk)
{
    STACK s = (struct celltype *)malloc(sizeof(struct celltype));
    s->data = elm;
    s->next = stk->next;
    stk->next = s;
}
void PushStack(float elm, AnsSTACK stk)
{
    AnsSTACK s = (struct node *)malloc(sizeof(struct node));
    s->data = elm;
    s->next = stk->next;
    stk->next = s;
}

//��ջ
char Pop(STACK stk)
{
    STACK s;
    char x;
    if(stk->next)
    {
        s = stk->next;
        x = s->data;
        stk->next = s->next;
        free(s);
    }
    return x;
}
float PopStack(AnsSTACK stk)
{
    AnsSTACK s;
    float x;
    if(stk->next)
    {
        s = stk->next;
        x = s->data;
        stk->next = s->next;
        free(s);
    }
    return x;
}

//p����һ���ڵ��������x
STACK Insert(char x, STACK p)
{
    STACK q;
    q = (struct celltype *)malloc(sizeof(struct celltype));
    q->data = x;
    q->next = NULL;
    p->next = q;
    return q;
}

//չʾ���
void Show(STACK L)
{
    STACK p = L;
    while(p->next)
    {
        printf("%c",p->next->data);
        p = p->next;
    }
    printf("\n");
}
void ShowAns(AnsSTACK ans)
{
    AnsSTACK q = ans;
    while(q->next)
    {
        printf("%f   ",q->next->data);
        q = q->next;
    }
    printf("\n");
}

//�����������ͷ�ڵ�
void ClearStack(STACK L)
{
    STACK p;
    while(L->next != NULL)
    {
        p = L->next;
        L->next = L->next->next;
        free(p);
    }
}
void ClearAnsStack(AnsSTACK L)
{
    AnsSTACK p;
    while(L->next != NULL)
    {
        p = L->next;
        L->next = L->next->next;
        free(p);
    }
}

//��׺ת��׺
void Change(char str[], STACK Ope, STACK Post)
{
    int i = 0;
    STACK p = Post;
    if(str[0] == '#')
    {
        i++;
        while(str[i]!='#')
        {
            //����
            while('0'<=str[i] && str[i]<='9')
            {
                p = Insert(str[i], p);
                i++;
                if(!('0'<=str[i] && str[i]<='9'))
                    p = Insert(' ', p);
            }
            printf("\n�����ջ����"); Show(Ope);
            printf("��ʱ�ĺ�׺����ʽΪ��"); Show(Post);
            //�ӷ��ͼ���
            if(str[i]=='+' || str[i] == '-')
            {
                if(Ope->next == NULL || Ope->next->data == '(')
                    Push(str[i], Ope);
                else
                {
                    do
                    {
                        p = Insert(Pop(Ope), p);
                        p = Insert(' ', p);
                    }while(Ope->next && Ope->next->data!='(');
                    Push(str[i], Ope);
                }
                printf("\n�����ջ����"); Show(Ope);
                printf("��ʱ�ĺ�׺����ʽΪ��"); Show(Post);
            }
            //������
            else if(str[i]=='(')
            {
                Push(str[i], Ope);
                printf("\n�����ջ����"); Show(Ope);
                printf("��ʱ�ĺ�׺����ʽΪ��"); Show(Post);
            }
            //�˷�������
            else if(str[i]=='/' || str[i]=='*')
            {
                if(Ope->next == NULL || Ope->next->data == '(')
                    Push(str[i], Ope);
                else
                {
                    while(Ope->next->data=='/' || Ope->next->data=='*')
                    {
                        p = Insert(Pop(Ope), p);
                        p = Insert(' ', p);
                    }
                    Push(str[i], Ope);
                }
                printf("\n�����ջ����"); Show(Ope);
                printf("��ʱ�ĺ�׺����ʽΪ��"); Show(Post);
            }
            //������
            else if(str[i]==')')
            {
                p = Insert(Pop(Ope), p);
                p = Insert(' ', p);
                while(Ope->next->data!='(')
                {
                    p = Insert(Pop(Ope), p);
                    p = Insert(' ', p);
                }
                Pop(Ope);
                printf("\n�����ջ����"); Show(Ope);
                printf("��ʱ�ĺ�׺����ʽΪ��"); Show(Post);
            }
            //�ո�
            else if(str[i]==' ');
            else if(str[i]=='#') break;
            else
            {
                printf("\n Wrong! \n");
                return;
            }
            i++;
        }
        //�������������
        while(Ope->next)
        {
            p = Insert(Pop(Ope), p);
            p = Insert(' ', p);
        }
        printf("\n���ĺ�׺����ʽΪ��"); Show(Post);
    }
}
//������
void Calculate(AnsSTACK ans, STACK Post)
{
    int i=0;
    char p;
    float a,b;
    do
    {
        i++;
        p = Pop(Post);
        if(p>='0' && p<='9')
        {
            if(ans->next==NULL)
                PushStack((float)(p-'0'), ans);
            else
                ans->next->data = 10*ans->next->data+(float)(p-'0');
        }
        else if(p==' ')
        {
            if(Post->next->data>='0' && Post->next->data<='9')
                PushStack(0, ans);
        }
        else if(p=='+'||p=='-'||p=='*'||p=='/')
        {
            b = PopStack(ans);
            a = PopStack(ans);
            if(p=='+') PushStack(a+b, ans);
            if(p=='-') PushStack(a-b, ans);
            if(p=='*') PushStack(a*b, ans);
            if(p=='/') PushStack(a/b, ans);
            printf("\n������ջ����"); ShowAns(ans);
            printf("���µĺ�׺����ʽ��"); Show(Post);
        }
        else
        {
            printf("\n Wrong! \n");
            return;
        }
    }while(Post->next->next != NULL);
}

/*
��ת��׺����ʽ������ֵ
��Ҫ˼·�������Ǹ���������£�ÿ������֮�����ҽ���һ�������
���������һλһ��������
�������ջ��ʱ��ans��ջ��ֵΪ0
�������ջ��ʱ��ans���γ�ջ����������ջ
*/
void Combination(char str[], STACK Ope, STACK Post, AnsSTACK ans)
{
    int i = 0;
    float a, b;
    char temp;
    STACK p = Post;
    if(str[0] == '#')
    {
        i++;
        while(str[i]!='#')
        {
            //���ִ���
            while('0'<=str[i] && str[i]<='9')
            {
                p = Insert(str[i], p);
                if(ans->next==NULL)
                    PushStack((float)(str[i]-'0'), ans);
                else
                    ans->next->data = 10*ans->next->data+(float)(str[i]-'0');
                i++;
                if(!('0'<=str[i] && str[i]<='9'))
                {
                    p = Insert(' ', p);
                    printf("\n�����ջ����"); Show(Ope);
                    printf("����ջ����"); ShowAns(ans);
                    break;
                }
            }
            //�ӷ��ͼ���
            if(str[i]=='+' || str[i] == '-')
            {

                if(Ope->next == NULL || Ope->next->data == '(')
                {
                    Push(str[i], Ope);
                    printf("\n�����ջ����"); Show(Ope);
                    printf("����ջ����"); ShowAns(ans);
                    PushStack(0, ans);
                }
                else
                {
                    do
                    {
                        temp = Pop(Ope);
                        p = Insert(temp, p);
                        p = Insert(' ', p);
                        b = PopStack(ans);
                        a = PopStack(ans);
                        if(temp == '+') PushStack(a+b, ans);
                        else if(temp == '-') PushStack(a-b, ans);
                        else if(temp == '*') PushStack(a*b, ans);
                        else if(temp == '/') PushStack(a/b, ans);
                        else;
                    }while(Ope->next && Ope->next->data!='(');
                    Push(str[i], Ope);
                    printf("\n�����ջ����"); Show(Ope);
                    printf("����ջ����"); ShowAns(ans);
                    PushStack(0, ans);
                }
            }
            //������
            else if(str[i]=='(')
            {
                Push(str[i], Ope);
                printf("\n�����ջ����"); Show(Ope);
                printf("����ջ����"); ShowAns(ans);
            }
            //�˷�������
            else if(str[i]=='/' || str[i]=='*')
            {

                if(Ope->next == NULL || Ope->next->data == '(')
                {
                    Push(str[i], Ope);
                    printf("\n�����ջ����"); Show(Ope);
                    printf("����ջ����"); ShowAns(ans);
                    PushStack(0, ans);
                }

                else
                {
                    while(Ope->next->data=='/' || Ope->next->data=='*')
                    {
                        temp = Pop(Ope);
                        p = Insert(temp, p);
                        p = Insert(' ', p);
                        b = PopStack(ans);
                        a = PopStack(ans);
                        if(temp == '*') PushStack(a*b, ans);
                        else if(temp == '/') PushStack(a/b, ans);
                        else;
                    }
                    Push(str[i], Ope);
                    printf("\n�����ջ����"); Show(Ope);
                    printf("����ջ����"); ShowAns(ans);
                    PushStack(0, ans);
                }
            }
            //������
            else if(str[i]==')')
            {
                do
                {
                    temp = Pop(Ope);
                    p = Insert(temp, p);
                    p = Insert(' ', p);
                    b = PopStack(ans);
                    a = PopStack(ans);
                    if(temp == '+') PushStack(a+b, ans);
                    else if(temp == '-') PushStack(a-b, ans);
                    else if(temp == '*') PushStack(a*b, ans);
                    else if(temp == '/') PushStack(a/b, ans);
                    else;
                }while(Ope->next->data!='(');
                Pop(Ope);
                printf("\n�����ջ����"); Show(Ope);
                printf("����ջ����"); ShowAns(ans);
            }
            //�ո�
            else if(str[i]==' ');
            else if(str[i]=='#') break;
            else
            {
                printf("\n Wrong! \n");
                return;
            }
            i++;
        }
        //�������������
        while(Ope->next)
        {
            temp = Pop(Ope);
            p = Insert(temp, p);
            p = Insert(' ', p);
            b = PopStack(ans);
            a = PopStack(ans);
            if(temp == '+') PushStack(a+b, ans);
            else if(temp == '-') PushStack(a-b, ans);
            else if(temp == '*') PushStack(a*b, ans);
            else if(temp == '/') PushStack(a/b, ans);
            else;
            printf("\n�����ջ����"); Show(Ope);
            printf("����ջ����"); ShowAns(ans);
        }
    }
    printf("\n��׺����ʽΪ��");
    Show(Post);
    printf("������Ϊ��");
    ShowAns(ans);
}


int main()
{
    FILE *file;
    char str[MAXBUFFER+1];
    if((file = fopen("test.txt","rt"))==NULL)
    {
        printf("Cannot open!\n");
        exit(0);
    }
    while(fgets(str, MAXBUFFER, file) != NULL)
        printf("�������������ʽΪ��%s\n",str);
    fclose(file);
    STACK Ope = MakeCharNull();
    STACK Post = MakeCharNull();
    AnsSTACK ans = MakeAnsNull();

    int cho;
    do{
        system("cls");
        printf("------------------------------\n");
        printf("--           0.QUIT         --\n");
        printf("--    1.��׺ת��׺����ʽ    --\n");
        printf("--   2.���ݺ�׺����ʽ����   --\n");
        printf("--  3.ת��׺����ʽͬʱ����  --\n");
        printf("------------------------------\n");
        printf("----What do you want to do?---\n");
        printf("  CHOOSE: ");
        scanf("%d", &cho);
        system("cls");
        if(cho == 1)
        {
            Change(str, Ope, Post);
            system("pause");
        }
        else if(cho == 2)
        {
            if(Post->next==NULL)
                printf("��û��ת��Ϊ��׺����ʽ��\n");
            else
            {
                Calculate(ans, Post);
                printf("\n������Ϊ��"); ShowAns(ans);
            }
            system("pause");
        }
        else if(cho == 3)
        {
            ClearAnsStack(ans);
            ClearStack(Ope);
            ClearStack(Post);
            Combination(str, Ope, Post, ans);
            ClearAnsStack(ans);
            ClearStack(Ope);
            ClearStack(Post);
            system("pause");
        }
        else if(cho == 0)
        {
            printf("�ɹ��˳�!");
            system("pause");
        }
        else
        {
            printf("û�и�ѡ��!");
            system("pause");
        }
    }while(cho != 0);
    return 0;
}
