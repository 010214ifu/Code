#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>

//�������ڵ�
struct node
{
    struct node *lchild;
    struct node *rchild;
    char data;
};
typedef struct node *BTREE;
typedef struct node *position;
//���к�ջ�Ľڵ�
struct celltype
{
    position data;
    struct celltype *next;
};
typedef struct celltype *STACK;
//�������У�ͷ��β
struct QUEUE
{
    struct celltype *front;
    struct celltype *rear;
};

//�����¶���
void MakeNullQueue(struct QUEUE *Q);
//�жϿն���
bool EmptyQueue(struct QUEUE Q);
//���
void EnQueue(position p, struct QUEUE *Q);
//����
void DeQueue(struct QUEUE *Q);
//��ǰ����
position FrontQueue(struct QUEUE *Q);
//������ջ
STACK MakeNullStack();
//�жϿ�ջ
bool EmptyStack(STACK stk);
//��ջ
void push(position p, STACK stk);
//��ջ
void Pop(STACK stk);
//ջ������
position Top(STACK stk);
//���������������������������ʽ����ṹ
void CreateBT(BTREE *sT);
//��������ĵݹ��㷨
void PreOrder(BTREE BT);
//��������ĵݹ��㷨
void InOrder(BTREE BT);
//��������ĵݹ��㷨
void PostOrder(BTREE BT);
//��������ķǵݹ��㷨
void PreOrderN(BTREE root);
//��������ķǵݹ��㷨
void InOrderN(BTREE root);
//��������ķǵݹ��㷨
void PostOrderN(BTREE root);
//�������
void LeverOrder(BTREE root);
//�ж���ȫ������
bool IsCompleteBTree(BTREE root);
//�����������
int WidthBTree(BTREE root);


int main()
{

    BTREE T; printf("�����������еĶ�������#��ʾ����������\n"); CreateBT(&T);
    printf("��������ݹ��㷨�������"); PreOrder(T); printf("\n");
    printf("��������ǵݹ��㷨�������"); PreOrderN(T); printf("\n");
    printf("��������ݹ��㷨�������"); InOrder(T); printf("\n");
    printf("��������ǵݹ��㷨�������"); InOrderN(T); printf("\n");
    printf("��������ݹ��㷨�������"); PostOrder(T); printf("\n");
    printf("��������ǵݹ��㷨�������"); PostOrderN(T); printf("\n");
    printf("��������㷨�������"); LeverOrder(T); printf("\n");
    printf("�������Ŀ���Ϊ��%d\n", WidthBTree(T));
    printf("�����Ƿ�Ϊ��ȫ��������");
    bool temp = IsCompleteBTree(T);
    if(temp == true) printf("��");
    else printf("��");
    return 0;
}

void MakeNullQueue(struct QUEUE *Q)
{

    Q->front=(struct celltype *)malloc(sizeof(struct celltype));
    Q->front->next=NULL;
    Q->rear=Q->front;
}

bool EmptyQueue(struct QUEUE Q)
{
    if(Q.front==Q.rear) return true;
    else return false;
}

void EnQueue(position p, struct QUEUE *Q)
{
    struct celltype *q=(struct celltype *)malloc(sizeof(struct celltype));
    q->data=p;
    q->next=NULL;
    Q->rear->next=q;
    Q->rear=q;
}

void DeQueue(struct QUEUE *Q)
{
    if(Q->front==Q->rear) printf("Queue is empty!");
    struct celltype *q=Q->front->next;
    Q->front->next=q->next;
    if(q->next==NULL) Q->rear=Q->front;
    free(q);
}

position FrontQueue(struct QUEUE *Q)
{
    if(Q->front->next) return Q->front->next->data;
    else return NULL;
}

STACK MakeNullStack()
{
    STACK s=(struct celltype *)malloc(sizeof(struct celltype));
    s->next=NULL;
    return s;
}

bool EmptyStack(STACK stk)
{
    if(stk->next) return false;
    else return true;
}

void push(position p, STACK stk)
{
    STACK s=(struct celltype *)malloc(sizeof(struct celltype));
    s->data=p;
    s->next=stk->next;
    stk->next=s;
}

void Pop(STACK stk)
{
    STACK s;
    if(stk->next)
    {
        s=stk->next;
        stk->next=s->next;
        free(s);
    }
}

position Top(STACK stk)
{
    if(stk->next) return stk->next->data;
    else return NULL;
}

void CreateBT(BTREE *sT)
{
    char ch;
    ch = getchar();
    if(ch == '#')
        (*sT) = NULL;
    else
    {
        (*sT) = (struct node *)malloc(sizeof(struct node));
        (*sT)->data = ch;
        CreateBT(&(*sT)->lchild);
        CreateBT(&(*sT)->rchild);
    }
}

void PreOrder(BTREE BT)
{
    if(BT!=NULL)
    {
        printf("%c",BT->data);
        PreOrder(BT->lchild);
        PreOrder(BT->rchild);
    }
}

void InOrder(BTREE BT)
{
    if(BT!=NULL)
    {
        InOrder(BT->lchild);
        printf("%c",BT->data);
        InOrder(BT->rchild);
    }
}

void PostOrder(BTREE BT)
{
    if(BT!=NULL)
    {
        PostOrder(BT->lchild);
        PostOrder(BT->rchild);
        printf("%c",BT->data);
    }
}

void PreOrderN(BTREE root)
{
    STACK stk=MakeNullStack();
    while(root!=NULL || !EmptyStack(stk))
    {
        while(root!=NULL)
        {
            printf("%c", root->data);
            push(root, stk);
            root = root->lchild;
        }
        if(!EmptyStack(stk))
        {
            root=Top(stk);
            Pop(stk);
            root=root->rchild;
        }
    }
}

void InOrderN(BTREE root)
{
    STACK stk=MakeNullStack();
    while(root!=NULL || !EmptyStack(stk))
    {
        while(root!=NULL)
        {
            push(root, stk);
            root = root->lchild;
        }
        if(!EmptyStack(stk))
        {
            root=Top(stk);
            Pop(stk);
            printf("%c", root->data);
            root=root->rchild;
        }
    }
}

void PostOrderN(BTREE root)
{
    STACK stk=MakeNullStack(), visited=MakeNullStack(), s;
    BTREE temp=root;
    while(root!=NULL || !EmptyStack(stk))
    {
        while(root!=NULL)
        {
            push(root, stk);
            root = root->lchild;
        }
        while(!EmptyStack(stk) && Top(visited)==Top(stk))
        {
            root = Top(stk);
            printf("%c", root->data);
            Pop(stk); Pop(visited);
        }
        if(!EmptyStack(stk))
        {
            s=(struct celltype *)malloc(sizeof(struct celltype));
            s->data=Top(stk);
            s->next=visited->next;
            visited->next=s;
            root = Top(stk)->rchild;
        }
        if(root==temp) break;
    }
}

void LeverOrder(BTREE root)
{
    struct QUEUE Q;
    MakeNullQueue(&Q);
    position p;
    if(root==NULL) return;
    EnQueue(root, &Q);
    while(Q.front!=Q.rear)
    {
        p=FrontQueue(&Q);
        DeQueue(&Q);
        printf("%c", p->data);
        if(p->lchild) EnQueue(p->lchild, &Q);
        if(p->rchild) EnQueue(p->rchild, &Q);
    }
}

bool IsCompleteBTree(BTREE root)
{
    struct QUEUE Q;
    MakeNullQueue(&Q);
    position q;
    if(root==NULL) return true;
    EnQueue(root, &Q);
    while(Q.front!=Q.rear)
    {
        q=FrontQueue(&Q);
        DeQueue(&Q);
        if(q!=NULL)
        {
            EnQueue(q->lchild, &Q);
            EnQueue(q->rchild, &Q);
        }
        else break;
    }
    while(Q.front!=Q.rear)
    {
        if(FrontQueue(&Q)!=NULL) return false;
        DeQueue(&Q);
    }
    return true;
}

int WidthBTree(BTREE root)
{
    struct QUEUE Q;
    MakeNullQueue(&Q);
    int wid=1,tempwid=0;
    position q;
    STACK temp;
    if (root==NULL) return 0;
    EnQueue(root, &Q);
    temp=Q.rear;
    while(Q.front!=Q.rear)
    {
        q=FrontQueue(&Q);
        if(q->lchild)
        {
            EnQueue(q->lchild, &Q);
            tempwid++;
        }
        if(q->rchild)
        {
            EnQueue(q->rchild, &Q);
            tempwid++;
        }
        if(Q.front->next==temp)
        {
            temp=Q.rear;
            if(tempwid>wid) wid=tempwid;
            tempwid=0;
        }
        DeQueue(&Q);
    }
    return wid;
}
