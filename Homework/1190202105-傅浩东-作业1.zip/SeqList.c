#include <stdio.h>
#include <stdlib.h>
#define Max_Size 100

struct LIST
{
    int elements[Max_Size];
    int last;
};
typedef int position;

void Delete(position p, struct LIST *L);//ɾ��ָ��λ�õ�����
void DeleteCertainData(struct LIST *L);//ɾ��ָ��Ԫ��
void DeleteRepeatedData(struct LIST *L);//���°�����������벢ɾ���ظ�����
void ReadData(struct LIST *L);//�������ݲ����α���
void Reverse(struct LIST *L, position p);//����1-p
void ShowData(struct LIST *L);//�������
void MoveRight(struct LIST *L);//�����ƶ���������
void MoveLeft(struct LIST *L);//�����ƶ���������
struct LIST Combination();//�ϲ������ź�����㷨
int Menu(struct LIST *L);//�˵�

int main()
{
    struct LIST L ;
    L.last = 0;
    int cho;
    do{
        cho = Menu(&L);
        switch(cho)
        {
        case 0:
            printf("Quit successfully!\n");
            break;
        case 1:
            ReadData(&L);
            break;
        case 2:
            ShowData(&L);
            DeleteCertainData(&L);
            break;
        case 3:
            DeleteRepeatedData(&L);
            break;
        case 4:
            Reverse(&L, L.last);
            break;
        case 5:
            MoveRight(&L);
            break;
        case 6:
            MoveLeft(&L);
            break;
        case 7:
            L = Combination();
            break;
        default:
            printf("No such choice!\n");
            break;
        }
        ShowData(&L);
        system("pause");
    }while(cho != 0);
    return 0;
}

int Menu(struct LIST *L)
{
    int cho;
    system("cls");
    printf("------------------------------\n");
    printf("--           0.QUIT         --\n");
    printf("--        1.INPUT DATA      --\n");
    printf("--   2.DELETE CERTAIN DATA  --\n");
    printf("--  3.DELETE REPEATED DATA  --\n");
    printf("--          4.REVERSE       --\n");
    printf("--        5.MOVE RIGHT      --\n");
    printf("--         6.MOVE LEFT      --\n");
    printf("--  7.MERGE DESCENDING DATA --\n");
    printf("------------------------------\n");
    printf("----What do you want to do?---\n");
    printf("  CHOOSE: ");
    scanf("%d", &cho);
    system("cls");
    return cho;
}


void Delete(position p, struct LIST *L)
{
    position q;
    if(p > L->last || p < 1)
        printf("The position don't exist.");
    else
    {
        L->last = L->last - 1;
        for(q = p; q <= L->last; q++)
            L->elements[q] = L->elements[q+1];
    }
}

void Reverse(struct LIST *L, position p)
{
    position i, mid = p/2;
    int temp;
    for(i = 1; i <= mid; i++)
    {
        temp = L->elements[i];
        L->elements[i] = L->elements[p+1-i];
        L->elements[p+1-i] = temp;
    }
}

void ShowData(struct LIST *L)
{
    position i;
    printf("LinList: ");
    for(i = 1; i<=L->last; i++)
        printf("->%d", L->elements[i]);
    printf("\n");
}

void ReadData(struct LIST *L)
{
    position i, k;
    L->last = 0;
    printf("How many numbers : ");
    scanf("%d", &k);
    if(k >= Max_Size-1) printf("No enough space!\n");
    else
    {
        for(i=1; i<=k; i++)
        {
            printf("Input the data ( %d / %d ) :", i, k);
            scanf("%d", &L->elements[i]);
            L->last++;
        }
    }
}

void DeleteCertainData(struct LIST *L)
{
    int num; position i;
    printf("Which number to delete? ");
    scanf("%d", &num);
    for(i=1; i<=L->last; i++)
        if(L->elements[i] == num)
        {
            Delete(i, L);
            i--;
        }
}

void DeleteRepeatedData(struct LIST *L)
{
    printf("Input data in descending or ascending order.\n");
    ReadData(L);
    for(position i=1; i<=L->last-1; i++)
        if(L->elements[i] == L->elements[i+1])
        {
            Delete(i, L);
            i--;
        }
}

void MoveRight(struct LIST *L)
{
    position k, m1, m2;
    printf("Number of Bits : ");
    scanf("%d", &k);
    m1 = L->last - k%L->last; m2 = L->last - m1;
    Reverse(L, m1);
    Reverse(&L->elements[m1], m2);
    Reverse(L, L->last);
}

void MoveLeft(struct LIST *L)
{
    position k, m1, m2;
    printf("Number of Bits : ");
    scanf("%d", &k);
    m1 = k%L->last; m2 = L->last - m1;
    Reverse(L, m1);
    Reverse(&L->elements[m1], m2);
    Reverse(L, L->last);
}

struct LIST Combination()
{
    struct LIST L1, L2, SumL;
    SumL.last = 0;
    printf("Input data in descending order.\n");
    printf("SeqList L1: \n");
    ReadData(&L1);
    printf("SeqList L2: \n");
    ReadData(&L2);

    while(L1.last > 0 && L2.last > 0)
    {
        SumL.last++;
        if(L1.elements[1] >= L2.elements[1])
        {
            SumL.elements[SumL.last] = L1.elements[1];
            Delete(1, &L1);
        }
        else
        {
            SumL.elements[SumL.last] = L2.elements[1];
            Delete(1, &L2);
        }
    }
    if(L1.last != 0)
        for(int i=1; i<=L1.last; i++)
        {
            SumL.last++;
            SumL.elements[SumL.last] = L1.elements[1];
            Delete(1, &L1);
        }
    else
        for(int j=1; j<=L2.last; j++)
        {
            SumL.last++;
            SumL.elements[SumL.last] = L2.elements[1];
            Delete(1, &L2);
        }
    return SumL;
}
