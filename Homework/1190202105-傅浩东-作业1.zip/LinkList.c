#include <stdio.h>
#include <stdlib.h>

struct celltype
{
    int data;
    struct celltype *next;
};
typedef struct celltype *LIST;
typedef struct celltype *position;


//��������
void ReadData(LIST L);//�������ݣ�������˳������
void Insert(int x, position p);//p����һ���ڵ��������x
void Delete(position p);//ɾ��p����һ���ڵ�
void ShowData(LIST L);//�������
int NumData(LIST L);//���������ݸ���
void ClearLink(LIST L);//�������������ͷָ��

//��ҵҪ����غ���
int Menu(LIST L);//ѡ����еĲ���
void DeleteCertainData(int x, LIST L);//ɾ��������ȫ��Ԫ��
void DeleteRepeatedData(LIST L);//ɾ���ź�������Ա����ظ�Ԫ��
void Reverse(LIST L);//����ʵ�ֵ���
void MoveRight(int k, LIST L);//�����ƶ�kλ
void MoveLeft(int k, LIST L);//�����ƶ�kλ
LIST Combination();//�ϲ������������е����Ա�

int main()
{
    int cho, k;
    LIST L = (struct celltype *)malloc(sizeof(struct celltype));
    if(L == NULL)
    {
        printf("No enough memory to allocate!\n");
        exit(0);
    }
    L->next = NULL;
    do{
        cho = Menu(L);
        switch(cho)
        {
        case 0:
            printf("Quit successfully!\n");
            break;
        case 1:
            ReadData(L);
            break;
        case 2:
            ShowData(L);
            printf("Which number to delete? ");
            scanf("%d", &k);
            DeleteCertainData(k, L);
            break;
        case 3:
            ClearLink(L);
            DeleteRepeatedData(L);
            break;
        case 4:
            Reverse(L);
            break;
        case 5:
            printf("Number of Bits:");
            scanf("%d", &k);
            MoveRight(k, L);
            break;
        case 6:
            printf("Number of Bits:");
            scanf("%d", &k);
            MoveLeft(k, L);
            break;
        case 7:
            ClearLink(L);
            L = Combination();
            break;
        default:
            printf("No such choice!\n");
            break;
        }
        ShowData(L);
        system("pause");
    }while(cho != 0);
//����ڴ�
    ClearLink(L);
    free(L);
    return 0;
}

void ClearLink(LIST L)
{
    while(L->next != NULL)
        Delete(L);
}

int Menu(LIST L)
{
    int cho;
    system("cls");
    printf("------------------------------\n");
    printf("--           0.QUIT         --\n");
    printf("--        1.INPUT DATA      --\n");
    printf("--   2.DELETE CERTAIN DATA  --\n");
    printf("--  3.DELETE REPEATED DATA  --\n");
    printf("--          4.REVERSE       --\n");
    printf("--        5.MOVE RIGHT      --\n");
    printf("--         6.MOVE LEFT      --\n");
    printf("--  7.MERGE DESCENDING DATA --\n");
    printf("------------------------------\n");
    printf("----What do you want to do?---\n");
    printf("  CHOOSE: ");
    scanf("%d", &cho);
    system("cls");
    return cho;
}

void ReadData(LIST L)
{
    position q = L;
    int x, k, num;
    printf("How many numbers : ");
    scanf("%d", &x);
//��ȡ���ݲ������������
    for(num = 0; num < x; num++)
    {
        printf("Input the Data( %d/%d ): ",num+1, x);
        scanf("%d", &k);
        Insert(k, q);
        q = q->next;
    }
}

void Insert(int x, position p)
{
    position q;
    q = (struct celltype *)malloc(sizeof(struct celltype));
    if(q == NULL)
    {
        printf("No enough memory to allocate!\n");
        exit(0);
    }
    q->data = x;
    q->next = NULL;
    p->next = q;
}

void Delete(position p)
{
    position q;
    if(p->next != NULL)
    {
        q = p->next;
        p->next = q->next;
        free(q);
    }
}

void ShowData(LIST L)
{
    position q = L->next;
    int sum = 0;
    printf("LinList: ");
    while(q != NULL && printf("->"))
    {
        printf("%d", q->data);
        q = q->next;
        sum++;
    }
    if(sum == 0) printf(" Empty!");
    printf("\n");
}

int NumData(LIST L)
{
    int sum = 0;
    position p = L->next;
    while(p != NULL)
    {
        sum++;
        p = p->next;
    }
    return sum;
}

void DeleteCertainData(int x, LIST L)
{
    position p = L;
    while(p != NULL && p->next != NULL)
    {
        if(p->next->data == x)
            Delete(p);
        else p = p->next;
    }
}

void DeleteRepeatedData(LIST L)
{
    position p = L;
    printf("Input data in descending or ascending order.\n");
    ReadData(L);
    while(p != NULL && p->next != NULL)
    {
        if(p->next->data == p->data)
            Delete(p);
        else p = p->next;
    }
}

void Reverse(LIST L)
{
    position p = L->next, q;
    if(p != NULL)
    {
        q = p->next;
        p->next = NULL;
        while(q != NULL)
        {
            p = q;
            q = q->next;
            p->next = L->next;
            L->next = p;
        }
    }
}

void MoveRight(int k, LIST L)
{
    position p = L, RL;
    int m = NumData(L) - k % NumData(L);
    for(int i = 0; i<m; i++)
        p = p->next;
    RL = (struct celltype *)malloc(sizeof(struct celltype));
    if(RL == NULL)
    {
        printf("No enough memory to allocate!\n");
        exit(0);
    }
    RL->next = p->next;
    p->next = NULL;
    Reverse(L);Reverse(RL);
    while(p->next != NULL)
        p = p->next;
    p->next = RL->next;
    Reverse(L);
}

void MoveLeft(int k, LIST L)
{
    position p = L, RL;
    int m = k % NumData(L);
    for(int i = 0; i<m; i++)
        p = p->next;
    RL = (struct celltype *)malloc(sizeof(struct celltype));
    if(RL == NULL)
    {
        printf("No enough memory to allocate!\n");
        exit(0);
    }
    RL->next = p->next;
    p->next = NULL;
    Reverse(L);Reverse(RL);
    while(p->next != NULL)
        p = p->next;
    p->next = RL->next;
    Reverse(L);
}

LIST Combination()
{
    printf("Input data in descending order.\n");

//�½������������潵�����е�����
    LIST RL = (struct celltype *)malloc(sizeof(struct celltype));
    if(RL == NULL)
    {
        printf("No enough memory to allocate!\n");
        exit(0);
    }
    RL->next = NULL;
    printf("Link RL : \n");
    ReadData(RL);

    LIST L = (struct celltype *)malloc(sizeof(struct celltype));
    if(L == NULL)
    {
        printf("No enough memory to allocate!\n");
        exit(0);
    }
    L->next = NULL;
    printf("Link L : \n");
    ReadData(L);
//������ϲ�������
    position temp;
    LIST SumL = (struct celltype *)malloc(sizeof(struct celltype));
    temp = SumL;
    if(SumL == NULL)
    {
        printf("No enough memory to allocate!\n");
        exit(0);
    }
    while(L->next != NULL && RL->next != NULL)
    {
        if(L->next->data >= RL->next->data)
        {
            temp->next = L->next;
            temp = temp->next;
            L->next = L->next->next;
            temp->next = NULL;
        }
        else
        {
            temp->next = RL->next;
            temp = temp->next;
            RL->next = RL->next->next;
            temp->next = NULL;
        }
    }
    if(L->next == NULL)
        temp->next = RL->next;
    else
        temp->next = L->next;
    return SumL;
}
